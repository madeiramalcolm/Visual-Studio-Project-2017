﻿namespace Restaurant_Management_System_Revival2K18_OOSE
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ComboBox1 = new System.Windows.Forms.ComboBox();
            this.lbla1 = new System.Windows.Forms.Label();
            this.Textbox3 = new System.Windows.Forms.TextBox();
            this.Textbox2 = new System.Windows.Forms.TextBox();
            this.Textbox1 = new System.Windows.Forms.TextBox();
            this.lblcont = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.lbladd = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.lbla2 = new System.Windows.Forms.Label();
            this.ComboBox2 = new System.Windows.Forms.ComboBox();
            this.Textbox5 = new System.Windows.Forms.TextBox();
            this.Textbox7 = new System.Windows.Forms.TextBox();
            this.lbluser = new System.Windows.Forms.Label();
            this.lblactype = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.Textbox6 = new System.Windows.Forms.TextBox();
            this.lbla5 = new System.Windows.Forms.Label();
            this.lbla4 = new System.Windows.Forms.Label();
            this.lblrepass = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.lblnote = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Yellow;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.ComboBox1);
            this.panel1.Controls.Add(this.lbla1);
            this.panel1.Controls.Add(this.Textbox3);
            this.panel1.Controls.Add(this.Textbox2);
            this.panel1.Controls.Add(this.Textbox1);
            this.panel1.Controls.Add(this.lblcont);
            this.panel1.Controls.Add(this.Label3);
            this.panel1.Controls.Add(this.lbladd);
            this.panel1.Controls.Add(this.lblname);
            this.panel1.Controls.Add(this.Label4);
            this.panel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.Location = new System.Drawing.Point(44, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(675, 306);
            this.panel1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(536, 226);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 28);
            this.button2.TabIndex = 471;
            this.button2.Text = "CLEAR";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 20);
            this.label1.TabIndex = 470;
            this.label1.Text = "Personal Details";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // ComboBox1
            // 
            this.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.ComboBox1.Location = new System.Drawing.Point(361, 151);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.Size = new System.Drawing.Size(80, 21);
            this.ComboBox1.TabIndex = 462;
            this.ComboBox1.SelectedIndexChanged += new System.EventHandler(this.cmbsex_SelectedIndexChanged);
            // 
            // lbla1
            // 
            this.lbla1.AutoSize = true;
            this.lbla1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbla1.ForeColor = System.Drawing.Color.Red;
            this.lbla1.Location = new System.Drawing.Point(90, 92);
            this.lbla1.Name = "lbla1";
            this.lbla1.Size = new System.Drawing.Size(12, 13);
            this.lbla1.TabIndex = 464;
            this.lbla1.Text = "*";
            // 
            // Textbox3
            // 
            this.Textbox3.Location = new System.Drawing.Point(130, 203);
            this.Textbox3.Name = "Textbox3";
            this.Textbox3.Size = new System.Drawing.Size(100, 20);
            this.Textbox3.TabIndex = 463;
            // 
            // Textbox2
            // 
            this.Textbox2.Location = new System.Drawing.Point(130, 144);
            this.Textbox2.Name = "Textbox2";
            this.Textbox2.Size = new System.Drawing.Size(100, 20);
            this.Textbox2.TabIndex = 461;
            // 
            // Textbox1
            // 
            this.Textbox1.Location = new System.Drawing.Point(130, 89);
            this.Textbox1.Name = "Textbox1";
            this.Textbox1.Size = new System.Drawing.Size(100, 20);
            this.Textbox1.TabIndex = 459;
            // 
            // lblcont
            // 
            this.lblcont.AutoSize = true;
            this.lblcont.BackColor = System.Drawing.Color.Transparent;
            this.lblcont.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcont.ForeColor = System.Drawing.Color.Black;
            this.lblcont.Location = new System.Drawing.Point(42, 206);
            this.lblcont.Name = "lblcont";
            this.lblcont.Size = new System.Drawing.Size(60, 13);
            this.lblcont.TabIndex = 465;
            this.lblcont.Text = "Contact *";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.BackColor = System.Drawing.Color.Transparent;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.ForeColor = System.Drawing.Color.Black;
            this.Label3.Location = new System.Drawing.Point(313, 151);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(28, 13);
            this.Label3.TabIndex = 466;
            this.Label3.Text = "Sex";
            // 
            // lbladd
            // 
            this.lbladd.AutoSize = true;
            this.lbladd.BackColor = System.Drawing.Color.Transparent;
            this.lbladd.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladd.ForeColor = System.Drawing.Color.Black;
            this.lbladd.Location = new System.Drawing.Point(40, 144);
            this.lbladd.Name = "lbladd";
            this.lbladd.Size = new System.Drawing.Size(61, 13);
            this.lbladd.TabIndex = 467;
            this.lbladd.Text = "Address *";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.Color.Transparent;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.Black;
            this.lblname.Location = new System.Drawing.Point(49, 92);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(43, 13);
            this.lblname.TabIndex = 468;
            this.lblname.Text = "Name ";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(344, 151);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(11, 13);
            this.Label4.TabIndex = 469;
            this.Label4.Text = "*";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Yellow;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.lbla2);
            this.panel2.Controls.Add(this.ComboBox2);
            this.panel2.Controls.Add(this.Textbox5);
            this.panel2.Controls.Add(this.Textbox7);
            this.panel2.Controls.Add(this.lbluser);
            this.panel2.Controls.Add(this.lblactype);
            this.panel2.Controls.Add(this.lblpass);
            this.panel2.Controls.Add(this.Textbox6);
            this.panel2.Controls.Add(this.lbla5);
            this.panel2.Controls.Add(this.lbla4);
            this.panel2.Controls.Add(this.lblrepass);
            this.panel2.Controls.Add(this.Label2);
            this.panel2.Controls.Add(this.lblnote);
            this.panel2.Controls.Add(this.label5);
            this.panel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(44, 338);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(675, 239);
            this.panel2.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(251, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 24);
            this.label6.TabIndex = 475;
            this.label6.Text = "Account Details";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(536, 192);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(99, 40);
            this.button3.TabIndex = 474;
            this.button3.Text = "CLEAR";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // lbla2
            // 
            this.lbla2.AutoSize = true;
            this.lbla2.Location = new System.Drawing.Point(76, 91);
            this.lbla2.Name = "lbla2";
            this.lbla2.Size = new System.Drawing.Size(11, 13);
            this.lbla2.TabIndex = 465;
            this.lbla2.Text = "*";
            // 
            // ComboBox2
            // 
            this.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox2.FormattingEnabled = true;
            this.ComboBox2.Items.AddRange(new object[] {
            "Employee",
            "Customer"});
            this.ComboBox2.Location = new System.Drawing.Point(115, 192);
            this.ComboBox2.Name = "ComboBox2";
            this.ComboBox2.Size = new System.Drawing.Size(100, 21);
            this.ComboBox2.TabIndex = 464;
            // 
            // Textbox5
            // 
            this.Textbox5.Location = new System.Drawing.Point(115, 91);
            this.Textbox5.Name = "Textbox5";
            this.Textbox5.Size = new System.Drawing.Size(100, 20);
            this.Textbox5.TabIndex = 460;
            // 
            // Textbox7
            // 
            this.Textbox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox7.Location = new System.Drawing.Point(405, 141);
            this.Textbox7.Name = "Textbox7";
            this.Textbox7.PasswordChar = '*';
            this.Textbox7.Size = new System.Drawing.Size(100, 22);
            this.Textbox7.TabIndex = 463;
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.BackColor = System.Drawing.Color.Transparent;
            this.lbluser.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.ForeColor = System.Drawing.Color.Black;
            this.lbluser.Location = new System.Drawing.Point(19, 94);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(53, 13);
            this.lbluser.TabIndex = 467;
            this.lbluser.Text = "User_ID";
            // 
            // lblactype
            // 
            this.lblactype.AutoSize = true;
            this.lblactype.BackColor = System.Drawing.Color.Transparent;
            this.lblactype.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblactype.ForeColor = System.Drawing.Color.Black;
            this.lblactype.Location = new System.Drawing.Point(19, 197);
            this.lblactype.Name = "lblactype";
            this.lblactype.Size = new System.Drawing.Size(86, 13);
            this.lblactype.TabIndex = 468;
            this.lblactype.Text = "Account Type";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.BackColor = System.Drawing.Color.Transparent;
            this.lblpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpass.ForeColor = System.Drawing.Color.Black;
            this.lblpass.Location = new System.Drawing.Point(18, 150);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(61, 13);
            this.lblpass.TabIndex = 469;
            this.lblpass.Text = "Password";
            // 
            // Textbox6
            // 
            this.Textbox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox6.Location = new System.Drawing.Point(115, 141);
            this.Textbox6.Name = "Textbox6";
            this.Textbox6.PasswordChar = '*';
            this.Textbox6.Size = new System.Drawing.Size(100, 22);
            this.Textbox6.TabIndex = 462;
            // 
            // lbla5
            // 
            this.lbla5.AutoSize = true;
            this.lbla5.Location = new System.Drawing.Point(85, 150);
            this.lbla5.Name = "lbla5";
            this.lbla5.Size = new System.Drawing.Size(11, 13);
            this.lbla5.TabIndex = 470;
            this.lbla5.Text = "*";
            // 
            // lbla4
            // 
            this.lbla4.AutoSize = true;
            this.lbla4.Location = new System.Drawing.Point(361, 146);
            this.lbla4.Name = "lbla4";
            this.lbla4.Size = new System.Drawing.Size(11, 13);
            this.lbla4.TabIndex = 472;
            this.lbla4.Text = "*";
            // 
            // lblrepass
            // 
            this.lblrepass.AutoSize = true;
            this.lblrepass.BackColor = System.Drawing.Color.Transparent;
            this.lblrepass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrepass.ForeColor = System.Drawing.Color.Black;
            this.lblrepass.Location = new System.Drawing.Point(262, 146);
            this.lblrepass.Name = "lblrepass";
            this.lblrepass.Size = new System.Drawing.Size(109, 13);
            this.lblrepass.TabIndex = 473;
            this.lblrepass.Text = "Re-type Password";
            this.lblrepass.Click += new System.EventHandler(this.lblrepass_Click);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.BackColor = System.Drawing.Color.Transparent;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.ForeColor = System.Drawing.Color.Black;
            this.Label2.Location = new System.Drawing.Point(19, 60);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(79, 16);
            this.Label2.TabIndex = 457;
            this.Label2.Text = "left empty.";
            // 
            // lblnote
            // 
            this.lblnote.AutoSize = true;
            this.lblnote.BackColor = System.Drawing.Color.Transparent;
            this.lblnote.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnote.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblnote.Location = new System.Drawing.Point(23, 30);
            this.lblnote.Name = "lblnote";
            this.lblnote.Size = new System.Drawing.Size(56, 15);
            this.lblnote.TabIndex = 458;
            this.lblnote.Text = "NOTE  :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(19, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(353, 16);
            this.label5.TabIndex = 459;
            this.label5.Text = "Any field with \"*\" sign means that field must not be ";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(49, 595);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(212, 61);
            this.button1.TabIndex = 2;
            this.button1.Text = "REGISTER";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkOrange;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(587, 606);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(132, 41);
            this.button4.TabIndex = 3;
            this.button4.Text = "HOME";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.ClientSize = new System.Drawing.Size(778, 745);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Registration";
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.Registration_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.ComboBox ComboBox1;
        internal System.Windows.Forms.Label lbla1;
        internal System.Windows.Forms.TextBox Textbox3;
        internal System.Windows.Forms.TextBox Textbox2;
        internal System.Windows.Forms.TextBox Textbox1;
        internal System.Windows.Forms.Label lblcont;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label lbladd;
        internal System.Windows.Forms.Label lblname;
        internal System.Windows.Forms.Label Label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        internal System.Windows.Forms.Label lbla2;
        internal System.Windows.Forms.ComboBox ComboBox2;
        internal System.Windows.Forms.TextBox Textbox5;
        internal System.Windows.Forms.TextBox Textbox7;
        internal System.Windows.Forms.Label lbluser;
        internal System.Windows.Forms.Label lblactype;
        internal System.Windows.Forms.Label lblpass;
        internal System.Windows.Forms.TextBox Textbox6;
        internal System.Windows.Forms.Label lbla5;
        internal System.Windows.Forms.Label lbla4;
        internal System.Windows.Forms.Label lblrepass;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label lblnote;
        internal System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button4;
    }
}